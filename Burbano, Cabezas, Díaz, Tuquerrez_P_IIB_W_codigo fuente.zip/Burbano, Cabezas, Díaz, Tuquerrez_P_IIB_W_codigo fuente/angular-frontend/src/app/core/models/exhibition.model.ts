export interface Exhibition{
  _id: string;
  name: string;
  date: string;
  description: string;
  url_principal_img: string;
  is_fair: boolean;
  artists: string[];
}
