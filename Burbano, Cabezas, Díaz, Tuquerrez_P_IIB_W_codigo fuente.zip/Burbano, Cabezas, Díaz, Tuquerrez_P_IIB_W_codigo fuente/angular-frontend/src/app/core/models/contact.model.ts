
export interface Contact{
  _id: string;
  name: string;
  email: string;
  contact_phone: string;
  status: number;
}
