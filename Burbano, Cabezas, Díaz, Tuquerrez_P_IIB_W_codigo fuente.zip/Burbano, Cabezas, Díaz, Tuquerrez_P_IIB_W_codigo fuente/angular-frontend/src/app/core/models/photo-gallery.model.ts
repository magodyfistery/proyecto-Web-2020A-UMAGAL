export interface PhotoGallery {
  name: string;
  url: string;
}
