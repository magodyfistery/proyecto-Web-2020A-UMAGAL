
export interface Client{
  _id: string;
  username: string;
  password: string;
  name: string;
  date_of_birth: string;
  address: string;
  contact_phone: string;
  role: string;
}
