import { SafeResourceUrl } from '@angular/platform-browser';

export interface Video{

  name: string;
  url: string;

}
