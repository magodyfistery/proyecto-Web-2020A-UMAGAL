export class Artwork{
    constructor(
    public _id:string,
    public name:string,
    public description:string,
    public username:string,
    public year:Number,
    public id_artist:string,
    public image:string
    ){}
}