import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-artists',
  templateUrl: './our-artists.component.html',
  styleUrls: ['./our-artists.component.scss']
})
export class OurArtistsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
