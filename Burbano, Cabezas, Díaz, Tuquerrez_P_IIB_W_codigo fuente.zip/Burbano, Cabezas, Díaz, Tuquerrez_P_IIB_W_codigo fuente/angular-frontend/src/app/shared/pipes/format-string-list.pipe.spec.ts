import { FormatStringListPipe } from './format-string-list.pipe';

describe('FormatStringListPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatStringListPipe();
    expect(pipe).toBeTruthy();
  });
});
